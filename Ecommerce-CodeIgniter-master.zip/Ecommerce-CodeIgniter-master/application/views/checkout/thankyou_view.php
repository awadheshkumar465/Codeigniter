<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

			<div class="container">
				<div class="row">
					<div class="col-md-9">
					<div style="margin-top:50px"></div>
					
					<h3>Thank You! <?=$CustomerName;?></h3>
						<p>Your <strong>Order Id</strong>: <?=$OrderId?> has been placed. 
						Your product will be delivered withing 72 hours at your doorstep. </p>
					</div>					
				</div>
			</div>
			
<!-- Facebook Pixel Code -->

