<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

<div class="container">
				<div class="row">
					<div class="col-md-9">
					<div style="margin-top:50px"></div>
					<div class="alert alert-danger">
					
					Your cart is empty
					</div>
					
					</div>
					
				</div>
			</div>