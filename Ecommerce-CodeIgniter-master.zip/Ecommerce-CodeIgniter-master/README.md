# Ecommerce CMS built using Codeigniter V.3

## Features
- Manage Products
- Manage Orders
- Reports

### Third Party Softwares Used
- This CMS uses Porto Theme for Client Uses and Admint LTE for Admin Use
- PHP Excel 
- Simple HTML DOM
- Infinite Scroll
    