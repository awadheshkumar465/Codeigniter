# E commerce With Codeigniter 3.0

 ===>          using codeigniter 3 back/end <br>
 ===>          using bootstrap front/end <br>
 ===>          using font-awesome front/end <br>

# Requirements
PHP 5.4.0 or later <br>
#NOTE : if you have php 7 it wii not working as fine  ,

### Admin Credentials
Admin -> Username - <b>admin</b> | password - <b>admin</b> <br>
### User Credentials
User -> username - <b>hicham</b> | password - <b>admin</b> <br>
User -> username - <b>dyaa</b> | password - <b>admin</b>


