	
	<!-- Footer -->

		<footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><?php foreach($get_footer as $footer):?><?=  $footer->all_value_settings;?><?php endforeach;?></p>
                </div>
            </div>
        </footer>