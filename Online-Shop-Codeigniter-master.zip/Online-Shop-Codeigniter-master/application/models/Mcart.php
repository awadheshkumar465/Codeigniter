<?php

/*
 * By Haidar Mar'ie Email = haidarvm@gmail.com MProduct
 */
class MCart extends CI_Model {

    function __construct() {
        parent::__construct();
    }
    
    function getAllCart() {
        return true;
    }
    
    function getAll() {
        return true;
    }
    
    function insert() {
        
    }
    
}