<!--   Content
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
<div class="content">
  <div class="container">
    <center><h4>Øur Støckist</h4></center>
    <h5>Bandung</h5>
    <div class="row">
        <div class="four columns">
            <h5><i>Linoleum</i></h5>
            Tommy - 087821733752 <br/>
            Jl. Sarijadi No21 Bandung <br/>
            linoleum_shop21@yahoo.co.id <br />
        </div>
        <div class="four columns">
            <h5><i>Blackjack</i></h5>
            NOVI - 089619748284 <br/>
            Jl. Trunojoyo No 28 Bandung <br/>
            blackjackadmintoko@gmail.com <br />
        </div>
        <div class="four columns">
            <h5><i>BadPaper</i></h5>
            Arin - 0856xxxxx <br/>
            Jl. Jalaprang No 15 Bandung <br/>
            linoleum_shop21@yahoo.co.id <br />
        </div>
    </div>
    <h5>Bogor</h5>
    <div class="row">
        <div class="four columns">
            <h5><i>Wordz</i></h5>
            Arie - 0817 766 767 <br/>
            Jl. Dadali No. 10, Tanah Sareal Bogor <br/>
            yougotwordz@gmail.com <br />
        </div>
        <div class="four columns">
            <h5><i>HeloRain</i></h5>
            Hendrick - 08116820494 <br/>
            Jl. Durian Raya No 24 Bogor <br/>
            helorain.bogor@gmail.com <br />
        </div>
    </div>
    <h5>Jakarta</h5>
    <div class="row">
        <div class="four columns">
            <h5><i>SIXPAX Tebet</i></h5>
            Febri pin bb : 7EBDD8A1 <br/>
            Sansan pin bb : 25be6730 <br/>
            Jl. Tebet Utara Dalam 24C Jakarta Tlp. 021-83787171 <br/>
            beatbox.distro@gmail.com <br />
        </div>
        <div class="four columns">
            <h5><i>SIXPAX Bintaro</i></h5>
            Abay 08811692801 <br/>
            Dony 088801865995 <br/>
            pin: 3112AD1A <br/>
            Jl. Bintaro Utama J3 No. 12 Sektor 1 Bintaro Jaya - Jakarta <br/>
            beatbox.distro@gmail.com <br />
        </div>
    </div>
    <h5>Bali</h5>
    <div class="row">
        <div class="four columns">
            <h5><i>SIXPAX Tebet</i></h5>
            Alung - / 0361 - 240223 <br/>
            Jl. Teuku Umar No. 41 Denpasar - Bali <br/>
            beatbox.distro@gmail.com <br />
        </div>
    </div>
  </div>
</div>