<style media="screen">
  .col-xs-2{
    height:800px;
    /*background-color:black;*/
    /*padding-right:2px;*/
    border-right:1px solid blue;
  }
  .col-xs-10{
    height: 800px;
    /*background-color: cyan;*/
    /*padding-left: 2px;*/
  }
</style>
<div class="section">
  <div class="row">
    <div class="col-xs-2">

    </div>
    <div class="col-xs-10">

    </div>
  </div>
</div>
