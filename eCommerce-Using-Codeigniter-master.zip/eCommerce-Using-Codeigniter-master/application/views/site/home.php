<div class="section">
  <div class="row">
    <div class="featured">
      <div class="row">
        <h2>Featured Products</h2>
        <div class="row">

        </div>
      </div>
    </div>

    <div class="">

    </div>
  </div>
</div>
